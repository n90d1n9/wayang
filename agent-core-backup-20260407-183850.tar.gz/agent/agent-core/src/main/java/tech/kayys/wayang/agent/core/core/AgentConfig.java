package tech.kayys.wayang.agent.core.core;

import io.smallrye.config.ConfigMapping;
import io.smallrye.config.WithDefault;
import io.smallrye.config.WithName;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Typed configuration mapping for the Gollek Agent framework with enhanced Gollek integration.
 *
 * <p>
 * All properties are read from the {@code gollek.agent} namespace via
 * MicroProfile Config. Values can come from {@code application.yaml},
 * environment variables ({@code GOLLEK_AGENT_DEFAULT_STRATEGY}), or any
 * registered ConfigSource.
 * </p>
 *
 * <p>
 * Inject in any CDI bean with:
 *
 * <pre>{@code
 * @Inject
 * AgentConfig config;
 * }</pre>
 * </p>
 *
 * <h2>Configuration Example:</h2>
 * <pre>{@code
 * gollek:
 *   agent:
 *     default-strategy: tool-calling
 *     default-max-steps: 15
 *     default-model: llama-3.1-8b
 *     provider:
 *       preferred: openai
 *       fallback-enabled: true
 *       local-preferred: true
 *     inference:
 *       default-temperature: 0.7
 *       default-max-tokens: 2048
 *       timeout: 60s
 *     security:
 *       quota-enabled: true
 *       max-tokens-per-hour: 100000
 *     checkpoint:
 *       enabled: true
 *       ttl-hours: 24
 * }</pre>
 * </p>
 *
 * @author Wayang AI Team
 * @version 2.0.0
 * @since 2026-03-28
 */
@ConfigMapping(prefix = "gollek.agent")
public interface AgentConfig {

    /** Default orchestration strategy when none is specified in the request. */
    @WithDefault("react")
    @WithName("default-strategy")
    String defaultStrategy();

    /** Default maximum number of reasoning steps per run. */
    @WithDefault("10")
    @WithName("default-max-steps")
    int defaultMaxSteps();

    /** Default wall-clock timeout for an entire run in seconds. */
    @WithDefault("120")
    @WithName("default-timeout-seconds")
    int defaultTimeoutSeconds();

    /** Default inference model id. */
    @WithDefault("default")
    @WithName("default-model")
    String defaultModel();

    // ── Provider Configuration ──────────────────────────────────────────────

    ProviderConfig provider();

    interface ProviderConfig {
        /** Preferred provider ID (e.g., openai, gguf, onnx) */
        @WithDefault("default")
        @WithName("preferred")
        String preferred();

        /** Enable automatic fallback to alternative providers */
        @WithDefault("true")
        @WithName("fallback-enabled")
        boolean fallbackEnabled();

        /** Prefer local providers (GGUF, ONNX) for cost efficiency */
        @WithDefault("false")
        @WithName("local-preferred")
        boolean localPreferred();

        /** List of enabled provider IDs */
        @WithName("enabled-providers")
        Optional<List<String>> enabledProviders();

        /** Provider-specific configurations */
        @WithName("configs")
        Map<String, ProviderSpecificConfig> configs();

        interface ProviderSpecificConfig {
            @WithName("api-key")
            Optional<String> apiKey();

            @WithName("base-url")
            Optional<String> baseUrl();

            @WithName("timeout-seconds")
            Optional<Integer> timeoutSeconds();

            @WithName("max-retries")
            @WithDefault("3")
            int maxRetries();
        }
    }

    // ── Inference Configuration ──────────────────────────────────────────────

    InferenceConfig inference();

    interface InferenceConfig {
        /** Default temperature for inference */
        @WithDefault("0.7")
        @WithName("default-temperature")
        double defaultTemperature();

        /** Default max tokens for inference */
        @WithDefault("2048")
        @WithName("default-max-tokens")
        int defaultMaxTokens();

        /** Default timeout for inference requests */
        @WithDefault("60s")
        @WithName("timeout")
        Duration timeout();

        /** Enable streaming responses */
        @WithDefault("true")
        @WithName("streaming-enabled")
        boolean streamingEnabled();

        /** Enable native tool calling when supported */
        @WithDefault("true")
        @WithName("tool-calling-enabled")
        boolean toolCallingEnabled();

        /** Context window size for history management */
        @WithDefault("8192")
        @WithName("context-window")
        int contextWindow();

        /** Enable context compression for long conversations */
        @WithDefault("true")
        @WithName("context-compression-enabled")
        boolean contextCompressionEnabled();
    }

    // ── Multi-tenancy ──────────────────────────────────────────────

    MultitenancyConfig multitenancy();

    interface MultitenancyConfig {
        @WithDefault("false")
        boolean enabled();

        @WithDefault("X-Tenant-Id")
        @WithName("header-name")
        String headerName();

        /** Enable tenant-specific quotas */
        @WithDefault("false")
        @WithName("quota-enabled")
        boolean quotaEnabled();

        /** Default tokens per hour per tenant */
        @WithDefault("100000")
        @WithName("default-tokens-per-hour")
        int defaultTokensPerHour();

        /** Default executions per hour per tenant */
        @WithDefault("100")
        @WithName("default-executions-per-hour")
        int defaultExecutionsPerHour();
    }

    // ── Memory ─────────────────────────────────────────────────────

    MemoryConfig memory();

    interface MemoryConfig {
        /** in-memory | redis | pg-vector */
        @WithDefault("in-memory")
        String backend();

        RedisMemoryConfig redis();

        ConversationMemoryConfig conversation();

        interface RedisMemoryConfig {
            @WithDefault("redis://localhost:6379")
            String url();

            @WithDefault("gollek:agent:")
            @WithName("key-prefix")
            String keyPrefix();

            @WithDefault("3600")
            @WithName("ttl-seconds")
            int ttlSeconds();
        }

        interface ConversationMemoryConfig {
            @WithDefault("50")
            @WithName("max-history-per-session")
            int maxHistoryPerSession();

            @WithDefault("7200")
            @WithName("session-ttl-seconds")
            int sessionTtlSeconds();

            /** Enable hierarchical memory (short-term, long-term, episodic) */
            @WithDefault("false")
            @WithName("hierarchical-enabled")
            boolean hierarchicalEnabled();
        }
    }

    // ── Orchestrators ──────────────────────────────────────────────

    OrchestratorConfig orchestrators();

    interface OrchestratorConfig {
        ReactConfig react();

        PlanAndExecuteConfig planAndExecute();

        ToolCallingConfig toolCalling();

        ReflexionConfig reflexion();

        MultiAgentConfig multiAgent();

        interface ReactConfig {
            @WithDefault("0.7")
            float temperature();

            @WithDefault("512")
            @WithName("max-tokens-per-step")
            int maxTokensPerStep();

            @WithName("stop-tokens")
            Optional<List<String>> stopTokens();
        }

        interface PlanAndExecuteConfig {
            @WithDefault("0.3")
            @WithName("planner-temperature")
            float plannerTemperature();

            @WithDefault("512")
            @WithName("planner-max-tokens")
            int plannerMaxTokens();

            @WithDefault("0.5")
            @WithName("executor-temperature")
            float executorTemperature();

            @WithDefault("512")
            @WithName("synthesiser-max-tokens")
            int synthesiserMaxTokens();
        }

        interface ToolCallingConfig {
            @WithDefault("0.7")
            float temperature();

            @WithDefault("2048")
            @WithName("max-tokens")
            int maxTokens();

            /** Enable parallel tool execution */
            @WithDefault("true")
            @WithName("parallel-execution-enabled")
            boolean parallelExecutionEnabled();

            /** Enable tool result caching */
            @WithDefault("true")
            @WithName("caching-enabled")
            boolean cachingEnabled();

            /** Tool cache TTL in minutes */
            @WithDefault("10")
            @WithName("cache-ttl-minutes")
            int cacheTtlMinutes();

            /** Maximum tool calls per iteration */
            @WithDefault("5")
            @WithName("max-tool-calls-per-iteration")
            int maxToolCallsPerIteration();
        }

        interface ReflexionConfig {
            @WithDefault("3")
            @WithName("max-reflections")
            int maxReflections();

            @WithDefault("0.2")
            @WithName("evaluator-temperature")
            float evaluatorTemperature();

            @WithDefault("0.6")
            @WithName("reviser-temperature")
            float reviserTemperature();

            /** Evaluation threshold keyword */
            @WithDefault("PASS")
            @WithName("evaluation-threshold")
            String evaluationThreshold();
        }

        interface MultiAgentConfig {
            @WithDefault("true")
            @WithName("enabled")
            boolean enabled();

            /** Maximum number of agents */
            @WithDefault("5")
            @WithName("max-agents")
            int maxAgents();

            /** Enable inter-agent communication */
            @WithDefault("true")
            @WithName("communication-enabled")
            boolean communicationEnabled();

            /** Agent communication timeout in seconds */
            @WithDefault("30")
            @WithName("communication-timeout-seconds")
            int communicationTimeoutSeconds();
        }
    }

    // ── Skill configuration ────────────────────────────────────────

    SkillsConfig skills();

    interface SkillsConfig {
        InferenceSkillConfig inference();

        RagSkillConfig rag();

        CodeExecutionSkillConfig codeExecution();

        HttpCallSkillConfig httpCall();

        interface InferenceSkillConfig {
            @WithDefault("true")
            boolean enabled();

            @WithDefault("default")
            @WithName("default-model")
            String defaultModel();

            @WithDefault("1024")
            @WithName("default-max-tokens")
            int defaultMaxTokens();

            @WithDefault("0.7")
            @WithName("default-temperature")
            float defaultTemperature();
        }

        interface RagSkillConfig {
            @WithDefault("true")
            boolean enabled();

            @WithDefault("agent-knowledge")
            @WithName("default-collection")
            String defaultCollection();

            @WithDefault("5")
            @WithName("default-top-k")
            int defaultTopK();

            @WithDefault("false")
            @WithName("vector-store-enabled")
            boolean vectorStoreEnabled();

            @WithDefault("default")
            @WithName("embedding-model")
            String embeddingModel();
        }

        interface CodeExecutionSkillConfig {
            @WithDefault("true")
            boolean enabled();

            @WithDefault("python3")
            @WithName("python-executable")
            String pythonExecutable();

            @WithDefault("node")
            @WithName("node-executable")
            String nodeExecutable();

            @WithDefault("10")
            @WithName("default-timeout-seconds")
            int defaultTimeoutSeconds();
        }

        interface HttpCallSkillConfig {
            @WithDefault("true")
            boolean enabled();

            @WithDefault("15")
            @WithName("default-timeout-seconds")
            int defaultTimeoutSeconds();

            @WithDefault("")
            @WithName("allowed-hosts")
            String allowedHosts();
        }
    }

    // ── Security Configuration ──────────────────────────────────────────────

    SecurityConfig security();

    interface SecurityConfig {
        /** Enable security enforcement */
        @WithDefault("true")
        @WithName("enabled")
        boolean enabled();

        /** Enable input validation */
        @WithDefault("true")
        @WithName("input-validation-enabled")
        boolean inputValidationEnabled();

        /** Enable output filtering */
        @WithDefault("true")
        @WithName("output-filtering-enabled")
        boolean outputFilteringEnabled();

        /** Enable prompt injection detection */
        @WithDefault("true")
        @WithName("prompt-injection-detection-enabled")
        boolean promptInjectionDetectionEnabled();

        /** Enable PII redaction */
        @WithDefault("true")
        @WithName("pii-redaction-enabled")
        boolean piiRedactionEnabled();

        /** Maximum input length in characters */
        @WithDefault("10000")
        @WithName("max-input-length")
        int maxInputLength();
    }

    // ── Checkpoint Configuration ──────────────────────────────────────────────

    CheckpointConfig checkpoint();

    interface CheckpointConfig {
        /** Enable checkpoint/resume functionality */
        @WithDefault("true")
        @WithName("enabled")
        boolean enabled();

        /** Checkpoint storage backend (memory, filesystem, database) */
        @WithDefault("filesystem")
        @WithName("storage-backend")
        String storageBackend();

        /** Checkpoint TTL in hours */
        @WithDefault("24")
        @WithName("ttl-hours")
        int ttlHours();

        /** Maximum checkpoints per run */
        @WithDefault("10")
        @WithName("max-per-run")
        int maxPerRun();

        /** Filesystem checkpoint directory */
        @WithDefault("/tmp/wayang/agent-checkpoints")
        @WithName("filesystem-dir")
        String filesystemDir();
    }

    // ── Metrics ─────────────────────────────────────────────────────

    MetricsConfig metrics();

    interface MetricsConfig {
        @WithDefault("true")
        boolean enabled();

        @WithDefault("true")
        @WithName("include-tenant-tag")
        boolean includeTenantTag();

        /** Enable detailed step-by-step metrics */
        @WithDefault("false")
        @WithName("detailed-steps-enabled")
        boolean detailedStepsEnabled();

        /** Enable token usage tracking */
        @WithDefault("true")
        @WithName("token-tracking-enabled")
        boolean tokenTrackingEnabled();

        /** Enable provider performance metrics */
        @WithDefault("true")
        @WithName("provider-metrics-enabled")
        boolean providerMetricsEnabled();
    }

    // ── Strategy Selection ──────────────────────────────────────────────

    StrategySelectionConfig strategySelection();

    interface StrategySelectionConfig {
        /** Enable adaptive strategy selection */
        @WithDefault("true")
        @WithName("adaptive-enabled")
        boolean adaptiveEnabled();

        /** Enable task type caching */
        @WithDefault("true")
        @WithName("task-cache-enabled")
        boolean taskCacheEnabled();

        /** Cache TTL in minutes */
        @WithDefault("60")
        @WithName("task-cache-ttl-minutes")
        int taskCacheTtlMinutes();
    }
}
